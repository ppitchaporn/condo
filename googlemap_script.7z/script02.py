import time
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
import re

#ref: https://www.scrapingdog.com/blog/scrape-google-map-reviews/

url1 = 'https://www.google.com/maps?authuser=0'
#'MRT เตาปูน', 'MRT บางซื่อ',

location_list = ['MRT เตาปูน', 'MRT บางซื่อ', 'MRT กำแพงเพชร', 'MRT จตุจักร', 'MRT พหลโยธิน', \
                 'MRT ลาดพร้าว', 'MRT รัชดาภิเษก', 'MRT สุทธิสาร', 'MRT ห้วยขวาง', 'MRT ศูนย์วัฒนธรรมแห่งประเทศไทย',\
                 'BTS พหลโยธิน 24', 'BTS สะพานควาย', 'BTS อารีย์', 'BTS ภาวนา', 'BTS โชคชัย 4', 'BTS ลาดพร้าว 71']

with sync_playwright() as pw:
    for locate in location_list:
        # creates an instance of the Chromium browser and launches it
        browser = pw.chromium.launch(headless=False)
        # creates a new browser page (tab) within the browser instance
        page = browser.new_page()
        # go to url with Playwright page element
        page.goto(url1)
        # search what you're looking for
        page.click('.NhWQq')
        search_word = 'คอนโด ใกล้ '
        page.keyboard.type(f"{search_word} {locate}")
        # press enter
        page.keyboard.press('Enter')
        time.sleep(6)
        #sort 2star up
        page.click('.e2moi')
        page.locator("#action-menu > div:nth-child(2)").first.click()
        time.sleep(2)

        condo_name = []
        star_list = []
        starnum_list = []
        links = []

        for i in range(4):
            try:
                html = page.inner_html('body')
                # create beautiful soup element
                soup = BeautifulSoup(html, 'html.parser')
                # select items
                categories = soup.select('.hfpxzc')
                last_category_in_page = categories[-1].get('aria-label')
                # scroll to the last item
                last_category_location = page.locator(
                    f"text={last_category_in_page}")
                last_category_location.scroll_into_view_if_needed()
            except:
                pass
            
            time.sleep(2)

        review_list_all = []
        address_list = []

        links = [item.get('href') for item in categories]
        lat_list = [re.findall(r'(-?\d+\.\d+)', link)[0] for link in links]
        long_list = [re.findall(r'(-?\d+\.\d+)', link)[1] for link in links]
        condo_name = [item.get('aria-label') for item in categories]
        star_list = [item.text for item in soup.select('.MW4etd')]
        starnum_list = [item.text[1:-1] for item in soup.select('.UY7F9')]

        for link in links:
        # go to subject link
            try:
                page.goto(link)
                time.sleep(5)

                #get address
                try:
                    html = page.inner_html('body')
                    soup = BeautifulSoup(html, 'html.parser')
                    address = soup.select('button.CsEnBe')
                    address_i = address[0].get('aria-label').split(':')[-1]
                    address_list.append(address_i)
                except:
                    address_list.append('')
                    pass

                # load all reviews
                page.locator("text='รีวิว'").first.click()
                time.sleep(5)
                
                for i in range(40):
                    try:
                        html = page.inner_html('body')
                        soup = BeautifulSoup(html, 'html.parser')
                        scrap = soup.select('.jftiEf.fontBodyMedium')
                        last_category_in_page = scrap[-1].get('aria-label')
                        # scroll to the last item
                        last_category_location = page.locator(
                            f"text={last_category_in_page}")
                        last_category_location.scroll_into_view_if_needed()
                    except:
                        pass
                    
                #get reviews
                html = page.inner_html('body')
                soup = BeautifulSoup(html, 'html.parser')
                reviews = soup.select('.MyEned')
                reviews = [review.find('span').text for review in reviews]
                review_list_all.append(reviews)
                #names = soup.select('.d4r55')
                #names = [name.text for name in names]
            
            except:
                review_list_all.append('')
                address_list.append('')
                pass

        data = {'condo_name': condo_name, 'latitude': lat_list, 'longitude': long_list, 'address_list': address_list,\
                'star': star_list, 'starnum_list': starnum_list, 'review_list_all': review_list_all, 'links': links}

        print('condo:',len(condo_name))
        print('lat:',len(lat_list))
        print('lon:',len(long_list))
        print('address:',len(address_list))
        print('star:',len(star_list))
        print('star_num:',len(starnum_list))
        print('review:',len(review_list_all))

        df = pd.DataFrame(data)
        df['starnum_list'].astype('int').abs()
        #df.to_csv('test1.csv', encoding='utf-8-sig', index=False)
        df.to_excel(f'{locate}_2.xlsx', index=False)
        page.close()
